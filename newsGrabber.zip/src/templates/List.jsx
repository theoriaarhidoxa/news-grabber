import React, {useState} from 'react';
import Item from "./Item";
import {useGlobalContext} from "../context";

const List = () => {
    const {savedItems, setSavedItems} = useGlobalContext();
    const [selectedCard, setSelectedCard] = useState(null);

    const handleDragStart = (e, card) => {
        setSelectedCard(card);
    };

    const handleDragLeave = e => {
        setSavedItems(savedItems.map(el => ({...el, currentSelection: false})));
    };

    const handleDragEnd = e => {
        setSavedItems(savedItems.map(el => ({...el, currentSelection: false})));
    };

    const handleDragOver = (e, current) => {
        e.preventDefault();
        setSavedItems(savedItems.map(el => el.url === current.url ? {...el, currentSelection: true} : el));
    };

    const handleDrop = (e, card) => {
        e.preventDefault();
        const reSorted = savedItems.map(el => {
            if (el.url === card.url) {
                return {...el, currentSelection: false, order: selectedCard.order};
            } else if (el.url === selectedCard.url) {
                return {...el, currentSelection: false, order: card.order};
            }

            return el;
        });
        setSavedItems(reSorted);
        localStorage.setItem('savedItems', JSON.stringify(reSorted));
    };

    return (
        <div className="wrapper__list">
            {savedItems.sort((a, b) => a.order - b.order).map(el => {
                return (
                    <div onDragStart={e => handleDragStart(e, el)}
                         onDragLeave={e => handleDragLeave(e)}
                         onDragOver={e => handleDragOver(e, el)}
                         onDragEnd={e => handleDragEnd(e)}
                         onDrop={e => handleDrop(e, el)}
                         onMouseLeave={e => handleDragEnd(e)}
                         draggable={true}
                         key={el.url}
                         className={el.currentSelection ? 'wrapper__list-item current' : 'wrapper__list-item'}>
                        <Item {...el} />
                    </div>
                )
            })}
        </div>
    );
};

export default List;
